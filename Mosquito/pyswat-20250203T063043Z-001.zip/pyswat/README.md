pyswat
===============
This repository contains a Python script to run the SWAT (Soil and Water Assessment Tool) model in parallel using Latin hypercube sampling (LHS) method. The script provides functions to sample parameters using LHS method, retrieve previously sampled parameters, run the model in parallel, and modify the input files of the model to run simulations for each sampled parameter set.
<br>

## Installation
1. Install Python 3.11
2. Clone this repository
3. Install required Python packages with `pip install -r requirements.txt`

## Usage
### sample code
```
python run_swat.py \
    --model_path /path/to/model \
    --bsn_parameter SURLAG_BSN ESCO_BSN EPCO_BSN RSDCO \
    --parameter CN2 GW_DELAY ALPHA_BF GWQMN GW_REVAP REVAPMN SOL_AWC SOL_K SOL_Z CH_K2 CH_N2 CANMX SOL_BD LAT_TTIME PRF LAT_SED \
    --sub 1~33 \
    --samples_n 1000 \
    --cal 2015,2020 \
    --val 2021,2022 \
    --obs flow_1_obs_daily.txt TP_1_obs_daily.txt \
    --time_step 1 \
    --exe swat2012_635 \
    --parallel 10 \
```

The available command-line arguments are:

- `model_path`: The path to the SWAT model.
- `bsn_parameter`: The .bsn parameters to be calibrated.
- `parameter`: The SWAT input parameters to be calibrated.
- `sub`: The subbasins to be calibrated, specified as a range in the format tart~end.
- `samples_n`: The number of samples to generate for Latin hypercube sampling.
- `cal`: The calibration period, specified as a comma-separated list of start and end years.
- `val`: The validation period, specified as a comma-separated list of start and end years.
- `obs`: The observed data files, specified as a space-separated list.
- `time_step`: The time step for the SWAT model simulation (0: monthly, 1: daily).
- `exe`: The name of the SWAT executable file.
- `parallel`: The number of parallel processes to use for running the model.
- `callback`: The index of the Latin hypercube sampling parameter to run a single simulation for. If specified, the parallel argument is ignored.

## Documentation
The documentation for the functions provided in the script is located in the code comments.

## Contact
If you have any questions or issues with pyswat, please contact:<br>
Byeongwon Lee<br>
Master course student<br>
Environmental Data Analysis Lab.<br>
Dept. Environmental Engineering, College of Urban Sciences<br>
University of Seoul<br>
Email: 2.hospitale@gmail.com