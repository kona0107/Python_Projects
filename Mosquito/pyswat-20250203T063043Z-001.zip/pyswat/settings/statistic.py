import pandas as pd
import hydroeval as he
import numpy as np
import os
from typing import List, Tuple
import matplotlib.pyplot as plt
from datetime import datetime
import dask.dataframe as dd

# fmt: off
def read_rch(path, exe):
    """
    Read SWAT reach output file.

    Args:
        path (str): path to reach file.
        exe (str): SWAT executable used to generate the output file, options: ["swat670.exe", "swat2012_635.exe"].

    Returns:
        pd.DataFrame: The reach data as a pandas DataFrame.
    """
    rch_col_names_swat670 = [
        "REACH", "RCH", "GIS", "MON", "AREAkm2", "FLOW_INcms",
        "FLOW_OUTcms", "EVAPcms", "TLOSScms", "SED_INtons", "SED_OUTtons",
        "SEDCONCmg/L", "ORGN_INkg", "ORGN_OUTkg", "ORGP_INkg", "ORGP_OUTkg",
        "NO3_INkg", "NO3_OUTkg", "NH4_INkg", "NH4_OUTkg", "NO2_INkg",
        "NO2_OUTkg", "MINP_INkg", "MINP_OUTkg", "CHLA_INkg", "CHLA_OUTkg",
        "CBOD_INkg", "CBOD_OUTkg", "DISOX_INkg", "DISOX_OUTkg", "SOLPST_INmg",
        "SOLPST_OUTmg", "SORPST_INmg", "SORPST_OUTmg", "REACTPSTmg", "VOLPSTmg",
        "SETTLPSTmg", "RESUSP_PSTmg", "DIFFUSEPSTmg", "REACBEDPSTmg", "BURYPSTmg",
        "BED_PSTmg", "BACTP_OUTct", "BACTLP_OUTct", "CMETAL#1kg", "CMETAL#2kg",
        "CMETAL#3kg", "TOT Nkg", "TOT Pkg", "NO3ConcMg/l", "WTMPdegc"
    ]

    rch_col_names_swat2012_635 = [
        "REACH", "RCH", "GIS", "MON", "AREAkm2", "FLOW_INcms",
        "FLOW_OUTcms", "EVAPcms", "TLOSScms", "SED_INtons", "SED_OUTtons",
        "SEDCONCmg/kg", "ORGN_INkg", "ORGN_OUTkg", "ORGP_INkg", "ORGP_OUTkg",
        "NO3_INkg", "NO3_OUTkg", "NH4_INkg", "NH4_OUTkg", "NO2_INkg",
        "NO2_OUTkg", "MINP_INkg", "MINP_OUTkg", "CHLA_INkg", "CHLA_OUTkg",
        "CBOD_INkg", "CBOD_OUTkg", "DISOX_INkg", "DISOX_OUTkg", "SOLPST_INmg",
        "SOLPST_OUTmg", "SORPST_INmg", "SORPST_OUTmg", "REACTPSTmg", "VOLPSTmg",
        "SETTLPSTmg", "RESUSP_PSTmg", "DIFFUSEPSTmg", "REACBEDPSTmg", "BURYPSTmg",
        "BED_PSTmg", "BACTP_OUTct", "BACTLP_OUTct", "CMETAL#1kg", "CMETAL#2kg",
        "CMETAL#3kg", "TOT Nkg", "TOT Pkg", "NO3ConcMg/l", "WTMPdegc", "SUB"
    ]

    rch_col_names_swat_c = [
        "REACH", "RCH", "GIS", "MON", "AREAkm2", "FLOW_INcms",
        "FLOW_OUTcms", "EVAPcms", "TLOSScms", "SED_INtons", "SED_OUTtons",
        "SEDCONCmg/kg", "ORGN_INkg", "ORGN_OUTkg", "ORGP_INkg", "ORGP_OUTkg",
        "NO3_INkg", "NO3_OUTkg", "NH4_INkg", "NH4_OUTkg", "NO2_INkg",
        "NO2_OUTkg", "MINP_INkg", "MINP_OUTkg", "CHLA_INkg", "CHLA_OUTkg",
        "CBOD_INkg", "CBOD_OUTkg", "DISOX_INkg", "DISOX_OUTkg", "SOLPST_Img",
        "SOLPST_Omg", "SORPST_Img", "SORPST_Omg", "REACTPSTmg", "VOLPSTmg",
        "SETTLPSTmg", "RESUSP_PSTmg", "DIFFPSTmg", "BEDPSTmg", "BURYPSTmg",
        "BED_PSTmg", "BACTP_Oct", "BACTLP_Oct", "CMETAL#1kg", "CMETAL#2kg",
        "CMETAL#3kg", "TOT Nkg", "TOT Pkg", "NO3ConcMg/l", "WTMPdegc",
        "RPOC_INkg", "RPOC_OUTkg", "LPOC_INkg", "LPOC_OUTkg", "RDOC_INkg",
        "RDOC_OUTkg", "LDOC_INkg", "LDOC_OUTkg", "DIC_INkg", "DIC_OUTkg",
        "TotalPOCkg", "TotalDOCkg", "TOC_OUTkg"
    ]
    
    if exe == "swat670.exe":
        rch = dd.read_csv(
            path,
            delim_whitespace = True,
            skipinitialspace=True,
            skiprows = 9,
            names = rch_col_names_swat670,
            encoding = "cp949",
            dtype={"MON": "float64"}
            )

    elif exe == "swat2012_635":
        rch = dd.read_csv(
            path,
            delim_whitespace = True,
            skipinitialspace=True,
            skiprows = 9,
            names = rch_col_names_swat2012_635,
            encoding = "cp949",
            dtype={"MON": "float64"}
            )

    elif exe in ["SWAT202202.release.linux", "SWAT-C_202304", "SWAT-C_202312", "SWAT-C_202312_test"]:
        rch = dd.read_csv(
            path, 
            sep="\s+", 
            skiprows=9, 
            encoding="cp949", 
            names=rch_col_names_swat_c,
            dtype={"MON": "float64"}
            )

    rch = rch.compute()
    return rch


def read_hru(path, exe):
    """
    Read SWAT HRU output file.

    Args:
        path (str): path to HRU file.

    Returns:
        pd.DataFrame: HRU data.
    """
    hru_col_names_swat670 = [
        "LULC", "HRU", "GIS", "SUB", "MGT",
        "MON.AREAkm2", "PRECIPmm", "SNOFALLmm", "SNOMELTmm", "IRRmm",
        "PETmm", "ETmm", "SW_INITmm", "SW_ENDmm", "PERCmm",
        "GW_RCHGmm", "DA_RCHGmm", "REVAPmm", "SA_IRRmm", "DA_IRRmm",
        "SA_STmm", "DA_STmm", "SURQ_GENmm", "SURQ_CNTmm", "TLOSSmm",
        "LATQGENmm", "GW_Qmm", "WYLDmm", "DAILYCN", "TMP_AVdgC",
        "TMP_MXdgC", "TMP_MNdg", "CSOL_TMPdg", "CSOLARMJ/m2", "SYLDt/ha",
        "USLEt/ha", "N_APPkg/ha", "P_APPkg/ha", "NAUTOkg/ha", "PAUTOkg/ha",
        "NGRZkg/ha", "PGRZkg/ha", "NCFRTkg/ha", "PCFRTkg/ha", "NRAINkg/ha",
        "NFIXkg/ha", "F-MNkg/ha", "A-MNkg/ha", "A-SNkg/ha", "F-MPkg/ha",
        "AO-LPkg/ha", "L-APkg/ha", "A-SPkg/ha", "DNITkg/ha", "NUPkg/ha",
        "PUPkg/ha", "ORGNkg/ha", "ORGPkg/ha", "SEDPkg/ha", "NSURQkg/ha",
        "NLATQkg/ha", "NO3Lkg/ha", "NO3GWkg/ha", "SOLPkg/ha", "P_GWkg/ha",
        "W_STRS", "TMP_STRS", "N_STRS", "P_STRS", "BIOMt/ha",
        "LAI", "YLDt/ha", "BACTPct", "BACTLPct", "WTAB CLIm",
        "WTAB SOLm", "SNOmm", "CMUPkg/ha", "CMTOTkg/ha", "QTILEmm",
        "TNO3kg/ha", "LNO3kg/ha", "GW_Q_Dmm", "LATQCNTmm", "TVAPkg/ha"
    ]

    hru_col_names_swat2012_635 = [
        "LULC", "HRU", "GIS", "SUB", "MGT",
        "MON.AREAkm2", "PRECIPmm", "SNOFALLmm", "SNOMELTmm", "IRRmm",
        "PETmm", "ETmm", "SW_INITmm", "SW_ENDmm", "PERCmm",
        "GW_RCHGmm", "DA_RCHGmm", "REVAPmm", "SA_IRRmm", "DA_IRRmm",
        "SA_STmm", "DA_STmm", "SURQ_GENmm", "SURQ_CNTmm", "TLOSSmm",
        "LATQGENmm", "GW_Qmm", "WYLDmm", "DAILYCN", "TMP_AVdgC",
        "TMP_MXdgC", "TMP_MNdg", "CSOL_TMPdg", "CSOLARMJ/m2", "SYLDt/ha",
        "USLEt/ha", "N_APPkg/ha", "P_APPkg/ha", "NAUTOkg/ha", "PAUTOkg/ha",
        "NGRZkg/ha", "PGRZkg/ha", "NCFRTkg/ha", "PCFRTkg/ha", "NRAINkg/ha",
        "NFIXkg/ha", "F-MNkg/ha", "A-MNkg/ha", "A-SNkg/ha", "F-MPkg/ha",
        "AO-LPkg/ha", "L-APkg/ha", "A-SPkg/ha", "DNITkg/ha", "NUPkg/ha",
        "PUPkg/ha", "ORGNkg/ha", "ORGPkg/ha", "SEDPkg/ha", "NSURQkg/ha",
        "NLATQkg/ha", "NO3Lkg/ha", "NO3GWkg/ha", "SOLPkg/ha", "P_GWkg/ha",
        "W_STRS", "TMP_STRS", "N_STRS", "P_STRS", "BIOMt/ha",
        "LAI", "YLDt/ha", "BACTPct", "BACTLPct", "WTAB CLIm",
        "WTAB SOLm", "SNOmm", "CMUPkg/ha", "CMTOTkg/ha", "QTILEmm",
        "TNO3kg/ha", "LNO3kg/ha", "GW_Q_Dmm", "LATQCNTmm"
    ]

    hru_col_names_swat_c = [
        'LULC', 'HRU', 'GIS', 'SUB', 'MGT',
        'MON', 'AREAkm2', 'PRECIPmm', 'SNOFALLmm', 'SNOMELTmm',
        'IRRmm', 'PETmm', 'ETmm', 'SW_INITmm', 'SW_ENDmm',
        'PERCmm', 'GW_RCHGmm', 'DA_RCHGmm', 'REVAPmm', 'SA_IRRmm',
        'DA_IRRmm', 'SA_STmm', 'DA_STmm', 'SURQ_GENmm', 'SURQ_CNTmm',
        'LATQGENmm', 'LATQCNTmm', 'QTILEmm', 'GW_Qmm', 'GW_Q_Dmm',
        'TLOSSmm', 'WYLDmm', 'DAILYCN', 'TMP_AVdgC', 'TMP_MXdgC',
        'TMP_MNdg', 'CSOLARMJ/m2', 'SYLDt/ha', 'USLEt/ha', 'ORGNkg/ha',
        'ORGPkg/ha', 'SEDPkg/ha', 'N_APPkg/ha', 'P_APPkg/ha', 'NAUTOkg/ha',
        'PAUTOkg/ha', 'NGRZkg/ha', 'PGRZkg/ha', 'NCFRTkg/ha', 'PCFRTkg/ha',
        'NRAINkg/ha', 'NFIXkg/ha', 'NUPkg/ha', 'PUPkg/ha', 'DNITkg/ha',
        'NSQkg/ha', 'NLQkg/ha', 'TNO3kg/ha', 'NGWkg/ha', 'NO3Lkg/ha',
        'NRgkg/ha', 'NReVkg/ha', 'NSepkg/ha', 'GWNLkg/ha', 'SA_Nkg/ha',
        'SQ_Pkg/ha', 'TVAPkg/ha', 'GWPkg/ha', 'W_STRS', 'TMP_STRS',
        'N_STRS', 'P_STRS', 'BIOMt/ha', 'LAI', 'YLDt/ha',
        'YLDgt/ha', 'YLDbt/ha', 'YLDtt/ha', 'YLDrt/ha', 'BACTPct',
        'BACTLPct', 'WTAB_CLIm', 'WTAB_SOLm', 'SNOmm', 'RSDt/ha',
        'COVt/ha', 'N2Og/ha', 'NOg/ha', 'VNH4kg/ha', 'DNNkg/ha',
        'NITNkg/ha', 'UNO3kg/ha', 'FNO3kg/ha', 'FNH4kg/ha', 'FRONkg/ha',
        'TNO3kg/ha_2', 'TNH3kg/ha', 'TONt/ha', 'S_OPt/ha', 'S_OCt/ha',
        'S_OSCt/ha', 'SedCkg/ha', 'SrfCkg/ha', 'LatCkg/ha', 'PerCkg/ha',
        'NPPCkg/ha', 'RspCkg/ha', 'FROCkg/ha', 'RPOCkg/ha', 'LPOCkg/ha',
        'RDOCkg/ha', 'LDOCkg/ha', 'DICkg/ha', 'SDOCkg/ha', 'LDOCkg/ha_2',
        'PDOCkg/ha', 'GDOCkg/ha', 'SDICkg/ha', 'LDICkg/ha', 'GDICkg/ha',
        'TDOCkg/ha', 'TDICkg/ha', 'SurTempC', 'SolT50cmC', 'ST100cmC',
        'ST150cmC', 'ST200cmC', 'ST300cmC', 'ST350cmC', 'ST1000cmC',
        'FrozeDay', 'RPONkg/ha', 'LPONkg/ha', 'SDONkg/ha', 'LDONkg/ha',
        'PDONkg/ha', 'rcDONkg/h', 'GDONkg/ha', 'dDONkg/ha', 'rvDONkg/h',
        'gpDONkg/h', 'shaDONkgh', 'rcDOCkg/h', 'dcDOCkg/h', 'rvDOCkg/h',
        'gpDOCkg/h', 'shaDOCkgh', 'GDICkg/ha_2', 'rcDICkg/h', 'rvDICkg/h',
        'gpDICkg/h', 'shaDICkgh', 'SOC1t/ha', 'SOC2t/ha', 'SOC3t/ha',
        'SOC4t/ha', 'SOC5t/ha', 'SOC6t/ha', 'SOC7t/ha', 'SOCt/ha8'
    ]

    if exe in ["SWAT202202.release.linux", "SWAT-C_202304", "SWAT-C_202312", "SWAT-C_202312_test"]:
        hru = dd.read_csv(
            path, 
            sep = "\s+", 
            skiprows = 9, 
            encoding = "cp949", 
            names = hru_col_names_swat_c,
            assume_missing = True,
            usecols = ["LULC", "MON", "SUB", "AREAkm2", "LAI", "ETmm", "YLDt/ha"]
            )
        hru = hru.compute()
        hru = hru.reset_index(drop=True)

    else:
        if exe == "swat670.exe":
            hru_col_names = hru_col_names_swat670
        elif exe == "swat2012_635":
            hru_col_names = hru_col_names_swat2012_635

        hru = dd.read_csv(
            path,
            delim_whitespace = True,
            skipinitialspace = True,
            skiprows = 9,
            names = hru_col_names,
            dtype = {5: "str"},
            encoding = "cp949",
            usecols = ["MON.AREAkm2", "SUB", "LAI", "ETmm"]
        )

        hru = hru.compute()
        hru["MON"] = hru["MON.AREAkm2"].str.split(".").str[0]
        hru["AREAkm2"] = "0." + hru["MON.AREAkm2"].str.split(".").str[-1]
        hru = hru.drop(columns=["MON.AREAkm2"])
        hru = hru.astype({"MON":"int", "AREAkm2":"float"})
        hru = hru.reset_index(drop=True)
        last_year = hru["MON"].max()
        last_year_index = hru[hru["MON"] == last_year].index[-1]
        hru = hru.iloc[:last_year_index+1,:]

    return hru


# fmt: on
def extract_variables(
    var: str, bsn: str, years: List[int], output_summary: pd.DataFrame, time_step: int, path: str
) -> List[float]:
    """
    Extract data from output files and calculate statistics.

    Args:
        var (str): variable of interest, options: ["ET", "LAI", "FLOW", "TN", "TP", "SS", "TOC", "POC", "DOC"].
        bsn (str): sub-basin number, options: ["00", "01", "02", ...].
        years (list): range of years to consider, format: [start, end].
        output_summary (pd.DataFrame): output summary file.
        time_step (int): time step, options: [0, 1, 2].
        path (str): path to output files.

    Returns:
        list : list of variable values.
    """
    target = {"ET": "ETmm", "LAI": "LAI", "FLOW": "FLOW_OUTcms", "TN": "TOT Nkg", "TP": "TOT Pkg", "SS": "SED_OUTtons", "TOC": "TOC_OUTkg", "POC": "TotalPOCkg", "DOC": "TotalDOCkg"}
    result = []

    if time_step == 0:
        idx = output_summary[output_summary["MON"] == 1].index
        sublists = []
        sublist = [idx[0]]

        for i in range(1, len(idx)):
            if idx[i] - idx[i-1] == 1:
                sublist.append(idx[i])
            else:
                sublists.append(sublist)
                sublist = [idx[i]]

        sublists.append(sublist)

        for i, year in enumerate(range(years[0], years[1] + 1)):
            if year == years[1]:
                df = output_summary.loc[sublists[i][0]:]
                
            else:
                df = output_summary.loc[sublists[i][0]:sublists[i+1][0]-1]

            if var in ["ET", "LAI"]:
                for month in sorted(df["MON"].unique()):
                    if month <= 1000:
                        if bsn == "00":
                            value = df.loc[df["MON"] == month, target[var]]
                            area = df.loc[df["MON"] == month, "AREAkm2"]
                            value = (value * area).sum() / area.sum()

                        else:
                            value = df.loc[(df["MON"] == month) & (df["SUB"] == int(bsn)), target[var]]
                            area = df.loc[(df["MON"] == month) & (df["SUB"] == int(bsn)), "AREAkm2"]
                            value = (value * area).sum() / area.sum()

                        result.append(value)

            elif var in ["FLOW", "TN", "TP", "SS", "TOC", "POC", "DOC"]:
                for month in sorted(df["MON"].unique()):
                    if month <= 1000:
                        if bsn == "00":
                            value = df.loc[df["MON"] == month, target[var]].sum()

                        else:
                            print(year, month)
                            value = df.loc[(df["MON"] == month) & (df["RCH"] == int(bsn)), target[var]].values[0]

                        result.append(value)

    elif time_step == 1:
        idx = output_summary[output_summary["MON"] == 1].index
        sublists = []
        sublist = [idx[0]]

        for i in range(1, len(idx)):
            if idx[i] - idx[i-1] == 1:
                sublist.append(idx[i])
            else:
                sublists.append(sublist)
                sublist = [idx[i]]

        sublists.append(sublist)

        for i, year in enumerate(range(years[0], years[1] + 1)):
            if year == years[1]:
                df = output_summary.loc[sublists[i][0]:]
                
            else:
                df = output_summary.loc[sublists[i][0]:sublists[i+1][0]-1]

            if var in ["ET", "LAI"]:
                for month in sorted(df["MON"].unique()):
                    if bsn == "00":
                        value = df.loc[df["MON"] == month, target[var]]
                        area = df.loc[df["MON"] == month, "AREAkm2"]
                        value = (value * area).sum() / area.sum()

                    else:
                        value = df.loc[(df["MON"] == month) & (df["SUB"] == int(bsn)), target[var]]
                        area = df.loc[(df["MON"] == month) & (df["SUB"] == int(bsn)), "AREAkm2"]
                        value = (value * area).sum() / area.sum()

                    result.append(value)

            elif var in ["FLOW", "TN", "TP", "SS", "TOC", "POC", "DOC"]:
                for month in sorted(df["MON"].unique()):
                    if bsn == "00":
                        value = df.loc[df["MON"] == month, target[var]].sum()

                    else:
                        value = df.loc[(df["MON"] == month) & (df["RCH"] == int(bsn)), target[var]].values[0]

                    result.append(value)

            elif var in ["CORN", "SOYB"]:
                df = df[df["LULC"] == var]
                sum = 0
                for month in sorted(df["MON"].unique()):
                    value = df.loc[df["MON"] == month, "YLDt/ha"]
                    area = df.loc[df["MON"] == month, "AREAkm2"]
                    value = (value * area).sum() / area.sum() * 1000
                    sum += value
                
                result.append(sum)

    make_csv(result, var, bsn, path)

    return result


def make_csv(result: List[List[int]], var: List[str], bsn: List[str], path: str) -> None:
    """
    Save the result to a CSV file.

    Args:
        result (List([int])): list of statistics
        var List([str]): variable of interest, options: ["ET", "LAI", "FLOW", "TN", "TP", "SS", "TOC", "POC", "DOC"]
        bsn List([str]): sub-basin number, options: ["00", "01", "02", ...]
        path (str): path to output files

    Returns:
        None
    """
    pd.DataFrame(result).T.to_csv(f"{path}/final_{var}_{bsn}.csv", index=False, header=False, mode="a")


def calculate_model_performance(
    path: str, obs: List[str], time_step: int, cal: List[int], val: List[int], num: int, exe: str
) -> None:
    """
    Calculate statistics for a given set of variables and sub-basins.

    Args:
        path (str): Path to the directory containing the input and output files.
        obs (List[str]): List of variable and sub-basin combinations to calculate statistics for.
        time_step (int): Time step to use for the calculations.
        cal (List[int]): Calibration period to use for the calculations.
        val (List[int]): Validation period to use for the calculations.
        num (int): A number identifying the specific set of input and output files.

    Returns:
        None
    """
    if time_step == 0:
        i = 12 * (cal[1] - cal[0] + 1)
    elif time_step == 1:
        i = (datetime.strptime(f"{cal[1]}1231", "%Y%m%d") - datetime.strptime(f"{cal[0]}0101", "%Y%m%d")).days + 1

    final_stats = []
    final_stats_col = []
    
    vars = []
    for obs_file in obs:
        var, bsn, *_ = obs_file.split("/")[-1].upper().split("_")
        vars.append(var)

    vars_set = set(vars)

    if vars_set & {"ET", "LAI"}:
        hru = read_hru(f"{path}/TxtInOut_{num}/output.hru", exe)
    if vars_set & {"FLOW", "TN", "TP", "SS", "TOC", "POC", "DOC", "CORN", "SOYB"}:
        rch = read_rch(f"{path}/TxtInOut_{num}/output.rch", exe)

    for obs_file in obs:
        var, bsn, *_ = obs_file.split("/")[-1].upper().split("_")

        if var in ["ET", "LAI", "CORN", "SOYB"]:
            output_summary = hru
            if var in ["CORN", "SOYB"]:
                i = cal[1] - cal[0] + 1
        else:
            output_summary = rch

        output_summary = output_summary.reset_index(drop=True)
        res = extract_variables(var, bsn, [cal[0], val[1]], output_summary, time_step, f"{path}/result_{num}")
        obs_data = pd.read_csv(obs_file, header=None, names=["cons"], skip_blank_lines=False, na_values=[-9999])
        nse_cal, nse_val, kge_cal, kge_val, pbias_cal, pbias_val = extract_statistics(res, obs_data, i)       

        if var in ["CORN", "SOYB"]:
            final_stats.extend([pbias_cal, pbias_val])
            final_stats_col.extend(
                [
                    f"{var}_cal_{bsn:>02}_pbias",
                    f"{var}_val_{bsn:>02}_pbias",
                ]
            )
        else:
            final_stats.extend([nse_cal, nse_val, kge_cal, kge_val, pbias_cal, pbias_val])
            final_stats_col.extend(
                [
                    f"{var}_cal_{bsn:>02}_nse",
                    f"{var}_val_{bsn:>02}_nse",
                    f"{var}_cal_{bsn:>02}_kge",
                    f"{var}_val_{bsn:>02}_kge",
                    f"{var}_cal_{bsn:>02}_pbias",
                    f"{var}_val_{bsn:>02}_pbias",
                ]
            )

    final_stats = np.array(final_stats).reshape(1, len(final_stats))
    df = pd.DataFrame(final_stats, columns=final_stats_col)

    if not os.path.exists(f"{path}/result_{num}/final_stats.csv"):
        df.to_csv(f"{path}/result_{num}/final_stats.csv", index=False)
    else:
        df.to_csv(f"{path}/result_{num}/final_stats.csv", index=False, header=False, mode="a")


def extract_statistics(
    res: List[float], obs_data: List[float], i: int
) -> Tuple[float, float, float, float, float, float]:
    """
    Extracts the statistics of the SWAT simulation.

    Args:
    res (List[float]): A list of the simulated results.
    obs_data (List[float]): A list of the observed data.
    i (int): Index used to split the data into calibration and validation sets.

    Returns:
    Tuple[float, float, float, float, float, float]: A tuple containing the following statistics:
        - Nash-Sutcliffe Efficiency for the calibration set
        - Nash-Sutcliffe Efficiency for the validation set
        - Kling-Gupta Efficiency for the calibration set
        - Kling-Gupta Efficiency for the validation set
        - Percent bias for the calibration set
        - Percent bias for the validation set
    """
    nse_cal = he.evaluator(he.nse, np.array(res)[:i], np.array(obs_data)[:i])[0]
    nse_val = he.evaluator(he.nse, np.array(res)[i:], np.array(obs_data)[i:])[0]
    kge_cal = he.evaluator(he.kge, np.array(res)[:i], np.array(obs_data)[:i])[0][0]
    kge_val = he.evaluator(he.kge, np.array(res)[i:], np.array(obs_data)[i:])[0][0]
    pbias_cal = he.evaluator(he.pbias, np.array(res)[:i], np.array(obs_data)[:i])[0]
    pbias_val = he.evaluator(he.pbias, np.array(res)[i:], np.array(obs_data)[i:])[0]

    return nse_cal, nse_val, kge_cal, kge_val, pbias_cal, pbias_val


def combine_statistics(path: str, parallel: int) -> None:
    """
    Combine the statistics from the multiple parallel runs into a single csv file.

    Args:
        path (str): The path to the directory containing the output of parallel runs.
        parallel (int): The number of parallel runs.

    Returns:
        None
    """
    os.makedirs(f"{path}/result", exist_ok=True)
    files = os.listdir(f"{path}/result_1")
    for file in files:
        dfs = []
        for i in range(1, parallel + 1):
            if file == "final_stats.csv":
                df = pd.read_csv(f"{path}/result_{i}/{file}")
            else:
                df = pd.read_csv(f"{path}/result_{i}/{file}", header=None)
            dfs.append(df)
        pd.concat(dfs).to_csv(f"{path}/result/{file}", index=False)

# def calculate_concentration(path: str, obs: List[str], time_step:int, cal: List[int]):
#     if time_step == 0:
#         i = 12 * (cal[1] - cal[0] + 1)
#     elif time_step == 1:
#         i = (datetime.strptime(f"{cal[1]}1231", "%Y%m%d") - datetime.strptime(f"{cal[0]}0101", "%Y%m%d")).days + 1
    
#     final_stats = []
#     final_stats_col = []
    
#     for obs_file in obs:
#         var, bsn, *_ = obs_file.split("/")[-1].upper().split("_")
        
#         if var in ["TN", "TP", "SS", "TOC", "POC", "DOC"]:
#             flow_sim = pd.read_csv(f"{path}/result/final_FLOW_{bsn}.csv", header=None)
#             target_sim = pd.read_csv(f"{path}/result/final_{var}_{bsn}.csv", header=None)
#             target_sim_concentration = target_sim / flow_sim / 86.4
            
#             last_index = obs_file.rfind(var)

#             if last_index != -1:
#                 flow_obs_path = obs_file[:last_index] + 'flow' + obs_file[last_index + len(var):]

#             flow_obs = pd.read_csv(flow_obs_path, header=None, names=["cons"], skip_blank_lines=False, na_values=[-9999])
#             target_obs = pd.read_csv(obs_file, header=None, names=["cons"], skip_blank_lines=False, na_values=[-9999])
#             target_obs_concentration = target_obs / flow_obs / 86.4

#             nse_cal, nse_val, kge_cal, kge_val, pbias_cal, pbias_val = extract_statistics(target_sim_concentration, target_obs_concentration, i)
#             final_stats.extend([nse_cal, nse_val, kge_cal, kge_val, pbias_cal, pbias_val])
#             final_stats_col.extend(
#                 [
#                     f"{var}_cal_{bsn:>02}_nse",
#                     f"{var}_val_{bsn:>02}_nse",
#                     f"{var}_cal_{bsn:>02}_kge",
#                     f"{var}_val_{bsn:>02}_kge",
#                     f"{var}_cal_{bsn:>02}_pbias",
#                     f"{var}_val_{bsn:>02}_pbias",
#                 ]
#             )

#     final_stats = np.array(final_stats).reshape(1, len(final_stats))
#     df = pd.DataFrame(final_stats, columns=final_stats_col)

#     if not os.path.exists(f"{path}/result/final_stats_concentration.csv"):
#         df.to_csv(f"{path}/result/final_stats_concentration.csv", index=False)
#     else:
#         df.to_csv(f"{path}/result/final_stats_concentration.csv", index=False, header=False, mode="a")


def extract_image(path: str, obs: List[str], cal: List[int], val: List[int], time_step: int):
    """
    Extracts image files from the output files generated by the parallel runs.

    Args:
        path (str): The path to the directory containing the output of parallel runs.
        obs (List[str]): List of paths to observation files.
        cal (List[int]): List containing the starting and ending year of the calibration period.
        val (List[int]): List containing the starting and ending year of the validation period.
        time_step (int): The time step of the simulation.

    Returns:
        None
    """
    files = sorted(os.listdir(f"{path}/result"))
    files = [f for f in files if ("CORN" not in f) and ("SOYB" not in f) and ("stats" not in f)]
    sorted_observed = sorted(obs, key=lambda x: x.upper())

    if time_step == 0:
        for i, f in enumerate(files):
            obs = pd.read_csv(
                sorted_observed[i],
                header=None,
                names=["cons"],
                skip_blank_lines=False,
                na_values=[-9999],
            )
            obs = np.array(obs["cons"])
            df = pd.read_csv(f"{path}/result/{f}")
            l95ppu = df.quantile(0.025, interpolation="inverted_cdf")
            u95ppu = df.quantile(0.975, interpolation="inverted_cdf")
            std = np.nanstd(obs)
            r_factor = np.mean(np.array(u95ppu) - np.array(l95ppu)) / std
            p_factor = ((l95ppu <= obs) & (obs <= u95ppu)).sum() / len(obs)

            plt.style.use("default")
            fig, ax = plt.subplots(dpi=200, figsize=(8, 4))
            ax.plot(range(len(obs)), u95ppu, color="mediumaquamarine")
            ax.plot(range(len(obs)), l95ppu, color="mediumaquamarine")
            ax.plot(range(len(obs)), obs, label="observation")
            ax.fill_between(range(len(obs)), l95ppu, u95ppu, color="mediumaquamarine", label="95PPU")
            ax.set_xlim([0, len(obs)])
            ax.set_ylim([0, ax.get_ylim()[1] * 1.2])
            ax.annotate(
                text="",
                xy=(0, ax.get_ylim()[1]),
                xytext=(12 * (val[0] - cal[0]), ax.get_ylim()[1]),
                arrowprops=dict(arrowstyle="<->"),
            )
            ax.annotate(
                text="",
                xy=(12 * (val[0] - cal[0]), ax.get_ylim()[1]),
                xytext=(12 * (val[1] + 1 - cal[0]), ax.get_ylim()[1]),
                arrowprops=dict(arrowstyle="<->"),
            )
            ax.vlines(12 * (val[0] - cal[0]), 0, ax.get_ylim()[1], color="black", linestyles=":")
            ax.text((val[0] - cal[0]) * 6, ax.get_ylim()[1] * 1.01, s="calibration", ha="center")
            ax.text(
                (val[1] + 1 - val[0]) * 6 + (val[0] - cal[0]) * 12, ax.get_ylim()[1] * 1.01, s="validation", ha="center"
            )
            ax.text(
                1,
                ax.get_ylim()[1] - ax.get_ylim()[1] / 50,
                s=f"R-factor = {round(r_factor,3)}\nP-factor = {round(p_factor,3)}",
                va="top",
            )
            ax.legend(loc=1)
            ax.set_xticks(list(range(0, len(obs) + 1, 12)), list(range(cal[0], val[1] + 2)))
            ax.spines["top"].set_visible(False)
            plt.tight_layout()
            plt.savefig(f"{path}/result/{f.split('.')[0]}.png")
            plt.close()
    
    else:
        for i, f in enumerate(files):
            if f != "final_stats.csv":
                obs = pd.read_csv(
                    sorted_observed[i],
                    header=None,
                    names=["cons"],
                    skip_blank_lines=False,
                    na_values=[-9999],
                )
                obs = np.array(obs["cons"])
                df = pd.read_csv(f"{path}/result/{f}")
                l95ppu = df.quantile(0.025, interpolation="inverted_cdf")
                u95ppu = df.quantile(0.975, interpolation="inverted_cdf")
                std = np.nanstd(obs)
                r_factor = np.mean(np.array(u95ppu) - np.array(l95ppu)) / std
                p_factor = ((l95ppu <= obs) & (obs <= u95ppu)).sum() / len(obs)

                plt.style.use("default")
                fig, ax = plt.subplots(dpi=200, figsize=(8, 4))
                ax.plot(range(len(obs)), u95ppu, color="mediumaquamarine")
                ax.plot(range(len(obs)), l95ppu, color="mediumaquamarine")
                ax.plot(range(len(obs)), obs, "bo", label="observation", markersize=1)
                ax.fill_between(range(len(obs)), l95ppu, u95ppu, color="mediumaquamarine", label="95PPU")
                ax.set_xlim([0, len(obs)])
                ax.set_ylim([0, ax.get_ylim()[1] * 1.2])
                
                start_date = pd.Timestamp(cal[0], 1, 1)
                end_date = pd.Timestamp(val[1], 12, 31)
                dates = pd.date_range(start=start_date, end=end_date, freq='Y')
                split_index = (pd.Timestamp(val[0], 1, 1) - start_date).days

                ax.vlines(split_index, 0, ax.get_ylim()[1], color="black", linestyles=":")
                ax.text(split_index / 2, ax.get_ylim()[1] * 1.01, s="calibration", ha="center")
                ax.text(split_index + (len(obs) - split_index) / 2, ax.get_ylim()[1] * 1.01, s="validation", ha="center")

                ax.text(
                    1,
                    ax.get_ylim()[1] - ax.get_ylim()[1] / 50,
                    s=f"R-factor = {round(r_factor,3)}\nP-factor = {round(p_factor,3)}",
                    va="top",
                )
                ax.legend(loc=1)
                ax.set_xticks([0] + [(pd.Timestamp(year, 1, 1) - start_date).days for year in range(cal[0] + 1, val[1] + 1)] + [len(obs) - 1])
                ax.set_xticklabels([date.strftime('%Y') for date in dates] + [str(val[1]+1)])
                ax.spines["top"].set_visible(False)
                plt.tight_layout()
                plt.savefig(f"{path}/result/{f.split('.')[0]}.png")
                plt.close()