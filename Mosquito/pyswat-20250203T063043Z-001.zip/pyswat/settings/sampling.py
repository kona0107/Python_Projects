from pyDOE import lhs
from settings import utils
import pandas as pd


def sample_parameters(parameter_path, samples, parameter, path, name, criterion="center"):
    """
    Samples given parameters using Latin hypercube sampling (LHS) method and saves the result to a csv file.

    Args:
        samples (int): Number of samples to generate.
        parameter (list): List of parameter names to be sampled.
        path (str): Path to the directory where the generated csv file will be saved.
        name (str): Name of the csv file.
        criterion (str, optional): The criterion used to sample the parameter space. Defaults to "center".

    Returns:
        pandas.DataFrame: A dataframe containing the sampled parameters.
    """
    lhd = pd.DataFrame(lhs(len(parameter), samples=samples, criterion=criterion), columns=parameter)

    df = utils.load_data(parameter_path, path)
    
    for p in parameter:
        if p == "CN2":
            p_min, p_max = (0.8, 1.2)

        elif df.loc[p]["FILE_EXT"] == "sol":
            p_min, p_max = (0.5, 1.5)

        else:
            p_min, p_max = df.loc[p][["MIN", "MAX"]]

        lhd.loc[:, p] = lhd.loc[:, p] * (p_max - p_min) + p_min

    for p in parameter:
        if p.endswith("/FRGRW1") or p.endswith("/LAIMX1"):
            land_cover, plant_code = p.split("/")
            first = p
            second = f"{land_cover}/{plant_code[:-1]}2"

            for i in range(samples):
                first_value = round(lhd.loc[i, first], 2)
                second_value = round(lhd.loc[i, second], 2)

                if second_value - first_value < 0.15:
                    second_value = first_value + 0.15
                    lhd.loc[i, second] = second_value

    for p in parameter:
        if "int" in df.loc[p, "FORMAT"].lower():
            lhd.loc[:, p] = lhd.loc[:, p].astype(int)
            
    lhd.to_csv(f"{path}/{name}.csv", index=False)

    return lhd


def get_sampled_parameters(settings):
    """
    Retrieves a list of sampled parameters according to the given settings.

    Args:
        settings (dict): A dictionary containing the settings for generating the sampled parameters.

    Returns:
        list: A list of dataframes, where each dataframe represents the sampled parameters of a specific setting.
    """
    default_parameter_data = utils.load_data(settings["parameter_path"], settings["model_path"])
    sampled_parameters = []
    bsn_file_parameters = settings["basin_parameters"]
    for i, par in enumerate(settings["sampled_parameters"]):
        check_basin_parameters(par, default_parameter_data)
        if bsn_file_parameters:
            settings["sampled_parameters"][i] = [x for x in par if x not in bsn_file_parameters]
        sampled_parameters.append(
            sample_parameters(
                settings["parameter_path"],
                settings["number_of_samples"],
                settings["sampled_parameters"][i],
                settings["model_path"],
                f"parameters_{i+1}",
            )
        )

    if bsn_file_parameters:
        bsn_lhd = sample_parameters(
            settings["parameter_path"], settings["number_of_samples"], bsn_file_parameters, settings["model_path"], "basin_parameters"
        )
        sampled_parameters.insert(0, bsn_lhd)

    return sampled_parameters


def check_basin_parameters(sampled_parameters, default_parameter_data):
    """
    Raises an error if any of the given parameters is a ".basin" parameter.

    Args:
        sampled_parameters (list): A list of parameter names to check.
        default_parameter_data (pandas.DataFrame): A dataframe containing the default parameter data.

    Raises:
        ValueError: If any of the given parameters is a ".basin" parameter.
    """
    for par in sampled_parameters:
        if default_parameter_data.loc[par, "FILE_EXT"] == "bsn":
            raise ValueError(f"The {par} parameters is .bs parameters.")


def get_existing_parameters(settings):
    """
    Retrieves a list of previously sampled parameters according to the given settings.
    
    Args:
        settings (dict): A dictionary containing the settings for retrieving the previously sampled parameters.

    Returns:
        list: A list of dataframes, where each dataframe represents the previously sampled parameters of a specific setting.
    """
    sampled_parameters = []
    for i, par in enumerate(settings["sampled_parameters"]):
        if settings["basin_parameters"]:
            settings["sampled_parameters"][i] = [x for x in par if x not in settings["basin_parameters"]]
        else:
            settings["sampled_parameters"][i] = [x for x in par]
        sampled_parameters.append(
            pd.read_csv(f"{settings['model_path']}/parameters_{i+1}.csv")
        )

    if settings["basin_parameters"]:
        bsn_lhd = pd.read_csv(f"{settings['model_path']}/basin_parameters.csv")
        sampled_parameters.insert(0, bsn_lhd)

    return sampled_parameters