import os
import asyncio
from typing import Any, List
import re


async def replace_line(copy_dir: str, subbasin: List[int], lhd: Any, params_df: Any, index: int) -> None:
    """Replace lines in the specified files with the values from the given dataframe.

    Args:
        copy_dir (str): The directory where the files to be modified are located.
        subbasin (list): A list of subbasin numbers.
        lhd (pd.DataFrame): A dataframe containing the Latin Hypercube Sampling parameter values.
        params_df (pd.DataFrame): A dataframe containing the parameter settings for the model.
        index (int): The index of the LHS sample to use.
    """
    ext = {}
    for i, x in enumerate(lhd, 0):
        for p in x:
            if not ext.get(f"parameter{i}"):
                ext[f"parameter{i}"] = [params_df.loc[p, "FILE_EXT"]]
            else:
                if not params_df.loc[p, "FILE_EXT"] in ext.get(f"parameter{i}"):
                    ext[f"parameter{i}"].append(params_df.loc[p, "FILE_EXT"])

    for i, v in enumerate(ext.values()):
        lhd_idx = lhd[i].iloc[index : index + 1]

        for ext_i in v:
            if ext_i == "bsn":
                await replace_other(copy_dir, lhd_idx, "basins.bsn", params_df)

            elif ext_i == "crop":
                await replace_crop(copy_dir, lhd_idx, params_df)

            else:
                if isinstance(subbasin[i - 1], list):
                    files = [f for f in os.listdir(copy_dir) if (f.endswith(ext_i))]
                    files = [f for f in files for sub in subbasin[i - 1] if f.startswith(f"{sub:>05}")]
                    batch_size = 10
                    file_batches = [files[i:i + batch_size] for i in range(0, len(files), batch_size)]

                    if ext_i == "rte":
                        for file_batch in file_batches:
                            tasks = [replace_rte(copy_dir, lhd_idx, f, params_df) for f in file_batch]
                            await asyncio.gather(*tasks)

                    elif ext_i == "sol":
                        for file_batch in file_batches:
                            tasks = [replace_sol(copy_dir, lhd_idx, f, params_df) for f in file_batch]
                            await asyncio.gather(*tasks)

                    elif ext_i == "mgt":
                        for file_batch in file_batches:
                            tasks = [replace_mgt(copy_dir, lhd_idx, f, params_df) for f in file_batch]
                            await asyncio.gather(*tasks)

                    elif ext_i == "sub":
                        pass
                    
                    elif (ext_i == "basins_cequal.wcp") or (ext_i == "basins_carbon.tes"):
                        file = ext_i
                        await replace_other(copy_dir, lhd_idx, file, params_df)
                        
                    else:
                        for file_batch in file_batches:
                            tasks = [replace_other(copy_dir, lhd_idx, f, params_df) for f in file_batch]
                            await asyncio.gather(*tasks)

                else:
                    raise TypeError("subbasin must be list type")


async def replace_other(copy_dir: str, lhd_idx: Any, file: str, params_df: Any) -> None:
    """
    Replace the values in other files (sep, bsn, gw, hru, swq, basins_cequal.wcp, basins_carbon.tes)
    with the values from the Latin Hypercube Sampling (LHS)

    Args:
        copy_dir (str): directory where the files are located
        lhd_idx (pd.DataFrame): dataframe containing the values to replace in the files
        file (str): name of the file to replace the values in
        params_df (pd.DataFrame): dataframe containing the parameter information

    Returns:
        None
    """
    file_path = os.path.join(copy_dir, file)
    length = {"sep": 13, "bsn": 16, "gw": 16, "hru": 16, "swq": 16, "basins_cequal.wcp": 16, "basins_carbon.tes": 16}
    
    def io(lines):
        params_col = list(lhd_idx.columns).copy()
        for i, line in enumerate(lines):
            for p in params_col:
                format = params_df.loc[p, "FORMAT"].lower()
                file_ext = params_df.loc[p, "FILE_EXT"]

                if line.find(p) < 0:
                    continue

                if "int" in format:
                    lines[i] = re.sub(
                        line[0 : length[file_ext]],
                        f"{int(lhd_idx[p].values[0]):{length[file_ext]}d}",
                        line,
                    )

                elif format == "float":
                    point = len(re.findall("\d+", lines[i])[1])

                    if p in ["kd_lp", "klrp", "klrd"]:
                        point = 3

                    if p == "klp":
                        point = 4

                    lines[i] = re.sub(
                        line[0 : length[file_ext]],
                        f"{lhd_idx[p].values[0]:{length[file_ext]}.{point}f}",
                        line,
                    )

                params_col.remove(p)
                break
        
        return lines

    try:
        with open(file_path, "r+") as f:
            lines = f.readlines()
            lines = io(lines)
            f.seek(0)
            f.writelines(lines)
            f.truncate()

    except UnicodeDecodeError:
        with open(file_path, "r+", encoding="cp949") as f:
            lines = f.readlines()
            lines = io(lines)
            f.seek(0)
            f.writelines(lines)
            f.truncate()


async def replace_crop(copy_dir: str, lhd_idx: Any, params_df: Any) -> None:
    """
    Replace the values in crop files with the values from the Latin Hypercube Sampling (LHS)

    Args:
        copy_dir (str): directory where the files are located
        lhd_idx (pd.DataFrame): dataframe containing the values to replace in the files
        params_df (pd.DataFrame): dataframe containing the parameter information

    Returns:
        None
    """
    try:
        with open(f"{copy_dir}/plant.dat", "r") as f:
            lines = f.readlines()
    except UnicodeDecodeError:
        with open(f"{copy_dir}/plant.dat", "r", encoding="cp949") as f:
            lines = f.readlines()

    plant = {}
    for i, line in enumerate(lines):
        for p in lhd_idx.columns:
            if params_df.loc[p, "FILE_EXT"] == "crop":
                land_cover, plant_code = p.split("/")

                if line.find(land_cover) < 0:
                    continue

                else:
                    plant["BIO_E"] = float(lines[i + 1][0:7].strip())
                    plant["HVSTI"] = float(lines[i + 1][7:14].strip())
                    plant["BLAI"] = float(lines[i + 1][14:22].strip())
                    plant["FRGRW1"] = float(lines[i + 1][22:30].strip())
                    plant["LAIMX1"] = float(lines[i + 1][30:36].strip())
                    plant["FRGRW2"] = float(lines[i + 1][36:43].strip())
                    plant["LAIMX2"] = float(lines[i + 1][43:50].strip())
                    plant["DLAI"] = float(lines[i + 1][50:57].strip())
                    plant["CHTMX"] = float(lines[i + 1][57:65].strip())
                    plant["RDMX"] = float(lines[i + 1][65:72].strip())

                    plant["T_OPT"] = float(lines[i + 2][0:7].strip())
                    plant["T_BASE"] = float(lines[i + 2][7:15].strip())
                    plant["CNYLD"] = float(lines[i + 2][15:24].strip())
                    plant["CPYLD"] = float(lines[i + 2][24:33].strip())
                    plant["BN1"] = float(lines[i + 2][33:42].strip())
                    plant["BN2"] = float(lines[i + 2][42:51].strip())
                    plant["BN3"] = float(lines[i + 2][51:60].strip())
                    plant["BP1"] = float(lines[i + 2][60:69].strip())
                    plant["BP2"] = float(lines[i + 2][69:78].strip())
                    plant["BP3"] = float(lines[i + 2][78:87].strip())

                    plant["WSYF"] = float(lines[i + 3][0:7].strip())
                    plant["USLE_C"] = float(lines[i + 3][7:16].strip())
                    plant["GSI"] = float(lines[i + 3][16:25].strip())
                    plant["VPDFR"] = float(lines[i + 3][25:32].strip())
                    plant["FRGMAX"] = float(lines[i + 3][32:40].strip())
                    plant["WAVP"] = float(lines[i + 3][40:48].strip())
                    plant["CO2HI"] = float(lines[i + 3][48:58].strip())
                    plant["BIOEHI"] = float(lines[i + 3][58:67].strip())
                    plant["RSDCO_PL"] = float(lines[i + 3][67:76].strip())
                    plant["ALAI_MIN"] = float(lines[i + 3][76:84].strip())

                    plant["BIO_LEAF"] = float(lines[i + 4][0:7].strip())
                    plant["MAT_YRS"] = int(lines[i + 4][7:14].strip())
                    plant["BMX_TREES"] = float(lines[i + 4][14:23].strip())
                    plant["EXT_COEF"] = float(lines[i + 4][23:31].strip())
                    plant["BM_DIEOFF"] = float(lines[i + 4][31:38].strip())

                    plant[plant_code] = lhd_idx[p].values[0]

                    lines[
                        i + 1
                    ] = f"{plant['BIO_E']:7.2f}{plant['HVSTI']:7.2f}{plant['BLAI']:8.2f}{plant['FRGRW1']:7.2f}{plant['LAIMX1']:7.2f}{plant['FRGRW2']:7.2f}{plant['LAIMX2']:7.2f}{plant['DLAI']:7.2f}{plant['CHTMX']:8.2f}{plant['RDMX']:7.2f}\n"
                    lines[
                        i + 2
                    ] = f"{plant['T_OPT']:7.2f}{plant['T_BASE']:8.2f}{plant['CNYLD']:9.4f}{plant['CPYLD']:9.4f}{plant['BN1']:9.4f}{plant['BN2']:9.4f}{plant['BN3']:9.4f}{plant['BP1']:9.4f}{plant['BP2']:9.4f}{plant['BP3']:9.4f}\n"
                    lines[
                        i + 3
                    ] = f"{plant['WSYF']:7.3f}{plant['USLE_C']:9.4f}{plant['GSI']:9.4f}{plant['VPDFR']:7.2f}{plant['FRGMAX']:8.3f}{plant['WAVP']:8.2f}{plant['CO2HI']:10.2f}{plant['BIOEHI']:9.2f}{plant['RSDCO_PL']:9.4f}{plant['ALAI_MIN']:8.3f}\n"
                    lines[
                        i + 4
                    ] = f"{plant['BIO_LEAF']:7.3f}{plant['MAT_YRS']:6d}{plant['BMX_TREES']:8.2f}{plant['EXT_COEF']:8.3f}{plant['BM_DIEOFF']:8.3f}\n"

    with open(f"{copy_dir}/plant.dat", "w") as f2:
        f2.writelines(lines)


async def replace_sub():
    """
    Replace the values in sub files

    Args:
        None

    Returns:
        None
    """
    pass


async def replace_rte(copy_dir: str, lhd_idx: Any, file: str, params_df: Any) -> None:
    """
    Replace the values in rte files with the values from the Latin Hypercube Sampling (LHS)

    Args:
        copy_dir (str): directory where the files are located
        lhd_idx (pd.DataFrame): dataframe containing the values to replace in the files
        file (str): name of the file to replace the values in
        params_df (pd.DataFrame): dataframe containing the parameter information

    Returns:
        None
    """
    file_path = os.path.join(copy_dir, file)

    def io(lines):
        for i, line in enumerate(lines):
            for p in lhd_idx.columns:

                if i == 23:
                    if re.match("CH_ERODMO", p):
                        num = int(p.lstrip("CH_ERODMO")) * 6
                        lines[i] = re.sub(line[num - 6 : num], f"{lhd_idx[p].values[0]:6.2f}", line)

                elif i == 28:
                    if re.match("HRU_SALT", p):
                        num = int(p.lstrip("HRU_SALT")) * 6
                        lines[i] = re.sub(line[num - 6 : num], f"{lhd_idx[p].values[0]:6.2f}", line)

                if line.find(p) < 0:
                    continue

                if "int" in params_df.loc[p, "FORMAT"].lower():
                    lines[i] = re.sub(line[0:14], f"{lhd_idx[p].values[0]:14d}", line)

                elif params_df.loc[p, "FORMAT"].lower() == "float":
                    point = len(re.findall("\d+", lines[i])[1])
                    lines[i] = re.sub(line[0:14], f"{lhd_idx[p].values[0]:14.{point}f}", line)

                break
        
        return lines

    try:
        with open(file_path, "r+") as f:
            lines = f.readlines()
            lines = io(lines)
            f.seek(0)
            f.writelines(lines)
            f.truncate()

    except UnicodeDecodeError:
        with open(file_path, "r+", encoding="cp949") as f:
            lines = f.readlines()
            lines = io(lines)
            f.seek(0)
            f.writelines(lines)
            f.truncate()


async def replace_sol(copy_dir: str, lhd_idx: Any, file: str, params_df: Any) -> None:
    """
    Replace the values in sol files with the values from the Latin Hypercube Sampling (LHS)

    Args:
        copy_dir (str): directory where the files are located
        lhd_idx (pd.DataFrame): dataframe containing the values to replace in the files
        file (str): name of the file to replace the values in
        params_df (pd.DataFrame): dataframe containing the parameter information

    Returns:
        None
    """
    rename = {
        "SOL_Z": "Depth",
        "SOL_BD": "Bulk Density Moist",
        "SOL_AWC": "Ave. AW Incl. Rock Frag",
        "SOL_K": "Ksat.",
        "SOL_CBN": "Organic Carbon",
        "CLAY": "Clay",
        "SILT": "Silt",
        "SAND": "Sand",
        "ROCK": "Rock Fragments",
        "SOL_ALB": "Soil Albedo",
        "USLE_K": "Erosion K",
        "SOL_EC": "Salinity",
        "SOL_CAL": "Soil CACO3",
        "SOL_PH": "Soil pH",
    }

    file_path = os.path.join(copy_dir, file)

    def io(lines):
        for i, line in enumerate(lines):
            for p in lhd_idx.columns:
                if p in rename and line.find(rename[p]) < 0:
                    continue

                if (p in rename) and (line.find(rename[p]) >= 0):
                    num = re.findall(r"[-+]?(?:\d*\.\d+|\d+)", line)
                    p_min, p_max = params_df.loc[p, ["MIN", "MAX"]]

                    values = list(map(lambda x: min(max(float(x) * lhd_idx[p].values[0], p_min), p_max), num))
                    lines[i] = re.sub(line[27:], ("{:12.2f}" * len(values)).format(*values) + "\n", line)

        return lines

    try:
        with open(file_path, "r+") as f:
            lines = f.readlines()
            lines = io(lines)
            f.seek(0)
            f.writelines(lines)
            f.truncate()

    except UnicodeDecodeError:
        with open(file_path, "r+", encoding="cp949") as f:
            lines = f.readlines()
            lines = io(lines)
            f.seek(0)
            f.writelines(lines)
            f.truncate()


async def replace_mgt(copy_dir: str, lhd_idx: Any, file: str, params_df: Any) -> None:
    """
    Replace the values in mgt files with the values from the Latin Hypercube Sampling (LHS)

    Args:
        copy_dir (str): directory where the files are located
        lhd_idx (pd.DataFrame): dataframe containing the values to replace in the files
        file (str): name of the file to replace the values in
        params_df (pd.DataFrame): dataframe containing the parameter information

    Returns:
        None
    """

    file_path = os.path.join(copy_dir, file)

    def io(lines):
        for i, line in enumerate(lines):
            for p in lhd_idx.columns:
                if line.find(p) < 0:
                    continue

                if p == "CN2":
                    p_min, p_max = params_df.loc[p, ["MIN", "MAX"]]

                    num = float(line[0:16]) * lhd_idx[p].values[0]
                    value = min(max(num, p_min), p_max)

                    lines[i] = re.sub(line[0:16], f"{value:16.2f}", line)
                    continue

                if "int" in params_df.loc[p, "FORMAT"].lower():
                    lines[i] = re.sub(line[0:16], f"{lhd_idx[p].values[0]:16d}", line)

                elif params_df.loc[p, "FORMAT"].lower() == "float":
                    point = len(re.findall("\d+", lines[i])[1])
                    lines[i] = re.sub(line[0:16], f"{lhd_idx[p].values[0]:16.{point}f}", line)

                    break

        return lines

    try:
        with open(file_path, "r+") as f:
            lines = f.readlines()
            lines = io(lines)
            f.seek(0)
            f.writelines(lines)
            f.truncate()
            
    except UnicodeDecodeError:
        with open(file_path, "r+", encoding="cp949") as f:
            lines = f.readlines()
            lines = io(lines)
            f.seek(0)
            f.writelines(lines)
            f.truncate()
   