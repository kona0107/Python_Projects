from logging.config import dictConfig
import logging


def log(filename, cnt, total, messages):
    """
    Log the progress of a loop.

    Args:
        filename (str): The name of the log file to write to.
        cnt (int): The current count of the loop.
        total (int): The total number of iterations in the loop.

    Returns:
        None
    """
    dictConfig(
        {
            "version": 1,
            "formatters": {
                "default": {
                    "format": "[%(asctime)s] %(message)s",
                }
            },
            "handlers": {
                "file": {
                    "level": "DEBUG",
                    "class": "logging.FileHandler",
                    "filename": f"{filename}",
                    "formatter": "default",
                },
            },
            "root": {"level": "DEBUG", "handlers": ["file"]},
        }
    )

    logging.debug(f"({cnt}/{total}) {messages}")
