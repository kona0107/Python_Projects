import datetime


def write_input_files(settings):
    """
    Write input variables to a text file.

    Args:
        settings (dict): a dictionary containing the input settings for the SWAT calibration & validation.

    Returns:
        None
    """
    with open(f"{settings['model_path']}/input_variables.txt", "w") as f:
        f.write(f"## SWAT calibration & validation settings\n")
        f.write(f"## Written at {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")

        for key in settings.keys():
            vals = settings[key]

            if type(vals) is list:
                vals = ", ".join(list(map(str, settings[key])))

            if (key == "sampled_parameters") or (key == "subbasin_number") or (key == "basin_parameters"):
                continue

            if key == "observed_data":
                f.write(f"{key}:\n")
                for v in vals.split(","):
                    f.write(f"  {v.split('/')[-1]}\n")

            else:
                f.write(f"{key}: {vals}\n")

        f.write("\nparameters\n")
        if (key == "basin_parameters") and vars:
            f.write(f"basin parameters: {', '.join(settings['basin_parameters'])}\n")
        else:
            f.write("basin_parameters: None\n")
        for i in range(len(settings["subbasin_number"])):
            f.write(
                f"{', '.join(list(map(str,settings['subbasin_number'][i])))}: {', '.join(settings['sampled_parameters'][i])}\n"
            )


def write_complete_files(settings):
    """
    Append the completion time to the input_variables.txt file.

    Args:
        settings (dict): a dictionary containing the input settings for the SWAT calibration & validation.

    Returns:
        None
    """
    with open(f"{settings['model_path']}/input_variables.txt", "a") as f:
        f.write(f"\n## Complete at {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
