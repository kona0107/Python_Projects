import argparse
import os
import shutil
import re
import pandas as pd
from typing import List, Union
import pickle as pkl


def load_data(parameter_path, model_path) -> pd.DataFrame:
    """
    Load SWAT calibration data from an Excel file.

    Args:
        model_path: Path to the Excel file containing the calibration data. Default is "/pyswat/bin/swat_parameters.xlsx".

    Returns:
        pd.DataFrame: A pandas DataFrame containing the calibration data.
    """
    if parameter_path:
        file_path = f"{model_path}/swat_parameters.xlsx"
    else:
        file_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'bin', 'swat_parameters.xlsx'))
    df = pd.read_excel(file_path, sheet_name=0, index_col="PARAMS")
    return df


def arg_to_string_list(s: Union[str, List[str]]) -> Union[str, List[str]]:
    """
    Convert the passed argument to string list.

    Args:
        s (Union[str, List[str]]): argument passed to the script.
    Returns:
        Union[str, List[str]]: list of strings.
    """
    if s is None:
        return s
    elif type(s) == list:
        if len(s) == 1:
            s = [y.strip() for x in s for y in x]
            return [s]
        return s
    elif len(s) == 1:
        v = s[0].split(",")
    else:
        v = [x.replace(",", "") for x in s]
    return v


def arg_to_int_list(s: Union[str, List[str]]) -> List[int]:
    """
    Convert the passed argument to integer list.

    Args:
        s (Union[str, List[str]]): argument passed to the script.
    Returns:
        List[int]: list of integers
    """
    if len(s) == 1:
        int_list = s[0].split(",")
    else:
        int_list = [x.replace(",", "") for x in s]
    int_list = [int(x) for x in int_list]
    return int_list


def parse_subbasin_range(lst: List[List[str]]) -> List[List[int]]:
    """
    Convert range of subbasin numbers to a list of integers.

    Args:
        lst (List[List[str]]): list of subbasin numbers passed to the script.
    Returns:
        List[List[int]]: list of integers
    """
    lst_copy = lst
    for i, x in enumerate(lst_copy):
        if ("~" in x[0]) or ("-" in x[0]):
            try:
                start, end = x[0].split("~")
            except:
                start, end = x[0].split("-")

            lst[i] = list(range(int(start), int(end) + 1))

        else:
            lst[i] = list(map(int, x))

    return lst


def get_observed_path(path, observed_data):
    """
    Returns a list of paths to observed data files in the specified directory and its subdirectories.

    Args:
        path (str): The path to search for observed data files.
        observed_data (List[str]): A list of filenames to search for.

    Returns:
        List[str]: A list of paths to observed data files.
    """
    observed_data_path = []
    for path, _, files in os.walk(path):
        for f in observed_data:
            if f in files:
                observed_data_path.append(os.path.join(path, f))
    return observed_data_path


def get_args():
    """
    Get command line arguments and parse them.

    Returns:
        argparse.Namespace: parsed command line arguments
    """
    parser = argparse.ArgumentParser(
        description="A script to run a SWAT model simulation with parallel processing capabilities.",
        epilog="""Use the --model_path argument to specify the model_path to the SWAT model,
                                  and use the --parameter argument to specify the parameters to be sampled. 
                                  Use the --samples_n argument to specify the number of samples to be generated, 
                                  and use the --parallel argument to specify the number of parallel processes to run.""",
    )

    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--bsn_parameter", nargs="*", type=str, default=None)
    parser.add_argument("-p", "--parameter", nargs="+", type=str, action="append", default=None)
    parser.add_argument("--samples_n", type=int, default=None, required=True)
    parser.add_argument("--cal", nargs="*", type=str)
    parser.add_argument("--val", nargs="*", type=str)
    parser.add_argument("--nyskip", type=int, default=2)
    parser.add_argument("--obs", nargs="*", type=str)
    parser.add_argument("--exe", default="swat670.exe", type=str)
    parser.add_argument("--time_step", type=int)
    parser.add_argument("-s", "--sub", nargs="+", type=str, action="append", default=None)
    parser.add_argument("--parallel", type=int)
    parser.add_argument("--callback", type=int, default=None)
    parser.add_argument("--parameter_path", action="store_true")

    return parser


def get_settings(args):
    """
    Create a settings dictionary from the passed arguments.

    Args:
        args (argparse.Namespace): parsed command line arguments

    Returns:
        dict: a dictionary containing the settings for the simulation
    """
    model_path = args.model_path
    bsn_parameter = args.bsn_parameter
    parameter = arg_to_string_list(args.parameter)
    samples_n = args.samples_n
    cal = arg_to_int_list(args.cal)
    val = arg_to_int_list(args.val)
    nyskip = args.nyskip
    obs = get_observed_path(model_path, args.obs)
    exe = args.exe
    time_step = args.time_step
    sub = parse_subbasin_range(args.sub)
    parallel = args.parallel
    callback = args.callback
    parameter_path = args.parameter_path

    settings = {
        "model_path": model_path,
        "basin_parameters": bsn_parameter,
        "sampled_parameters": parameter,
        "observed_data": obs,
        "number_of_samples": samples_n,
        "calibration_year": cal,
        "validation_year": val,
        "nyskip": nyskip,
        "time_step": time_step,
        "swat_executable": exe,
        "subbasin_number": sub,
        "parallel": parallel,
        "callback": callback,
        "parameter_path": parameter_path,
    }

    return settings


def get_default(settings: dict) -> None:
    """
    Set the default settings for the SWAT model simulation.

    This function copies the SWAT executable file to the TxtInOut directory,
    creates a tmp1.tmp file, and updates the time step in the file.cio file.

    Args:
        settings (dict): A dictionary containing the settings for the simulation.

    Returns:
        None
    """
    src_exe = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'bin', settings['swat_executable']))
    dst_exe = f"{settings['model_path']}/TxtInOut/"

    txtinout_dir = f"{settings['model_path']}/TxtInOut"
    dirlist = os.listdir(txtinout_dir)

    if settings["swat_executable"] not in dirlist:
        shutil.copy(src_exe, dst_exe)
        os.chmod(f"{settings['model_path']}/TxtInOut/{settings['swat_executable']}", 0o775)

    if "tmp1.tmp" not in dirlist:
        with open(f"{settings['model_path']}/TxtInOut/Tmp1.Tmp", "r", encoding="cp949") as f:
            lines = f.readlines()
        with open(f"{settings['model_path']}/TxtInOut/tmp1.tmp", "w", encoding="cp949") as f:
            f.writelines(lines)

    with open(f"{settings['model_path']}/TxtInOut/file.cio", "r", encoding="cp949") as f:
        lines = f.readlines()

        for i, line in enumerate(lines):
            if line.find("IPRINT") >= 0:
                lines[i] = re.sub(r"\d+", str(settings["time_step"]), line)
            
            if line.find("NYSKIP") >= 0:
                lines[i] = re.sub(r"\d+", str(settings["nyskip"]), line)

            if line.find("IYR") >= 0:
                lines[i] = re.sub(r"\d+", str(settings["calibration_year"][0] - settings["nyskip"]), line)

            if line.find("NBYR") >= 0:
                lines[i] = re.sub(line[0:16], f"{settings['validation_year'][1] - settings['calibration_year'][0] + settings['nyskip'] + 1:16d}", line)

            if line.find("IDAL") >= 0:
                if (settings["validation_year"][1] % 4) and (settings["validation_year"][1] % 400) == 0:
                    lines[i] = re.sub(r"\d+", str(366), line)
                else:
                    lines[i] = re.sub(r"\d+", str(365), line)

    with open(f"{settings['model_path']}/TxtInOut/file.cio", "w", encoding="cp949") as f:
        f.writelines(lines)

    if settings["swat_executable"] == "SWAT202202.release.linux":
        c_files_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../", "bin", "C-files"))
        
        if "basins.cbn" not in f"{settings['model_path']}/TxtInOut":
            shutil.copy2(f"{c_files_path}/basins.cbn", f"{settings['model_path']}/TxtInOut/basins.cbn")
            
        if "basins_bottom.alg" not in f"{settings['model_path']}/TxtInOut":
            shutil.copy2(f"{c_files_path}/basins_bottom.alg", f"{settings['model_path']}/TxtInOut/basins_bottom.alg")
            
        if "basins_carbon.sol" not in f"{settings['model_path']}/TxtInOut":
            shutil.copy2(f"{c_files_path}/basins_carbon.tes", f"{settings['model_path']}/TxtInOut/basins_carbon.tes")
            
        if "basins_cequal.swq" not in f"{settings['model_path']}/TxtInOut":
            shutil.copy2(f"{c_files_path}/basins_cequal.wcp", f"{settings['model_path']}/TxtInOut/basins_cequal.wcp")
            
        if "basins_energy.bal" not in f"{settings['model_path']}/TxtInOut":
            shutil.copy2(f"{c_files_path}/basins_energy.bal", f"{settings['model_path']}/TxtInOut/basins_energy.bal")
            
        if "basins_sedflux.dia" not in f"{settings['model_path']}/TxtInOut":
            shutil.copy2(f"{c_files_path}/basins_sedflux.dia", f"{settings['model_path']}/TxtInOut/basins_sedflux.dia")
            
        if "co2.dat" not in f"{settings['model_path']}/TxtInOut":
            shutil.copy2(f"{c_files_path}/co2.dat", f"{settings['model_path']}/TxtInOut/co2.dat")

        # os.remove(f"{settings['model_path']}/TxtInOut/plant.dat")
        # shutil.copy2(f"{c_files_path}/plant.dat", f"{settings['model_path']}/TxtInOut/plant.dat")

    result_dir = f"{settings['model_path']}/result"
    if os.path.exists(result_dir):
        shutil.rmtree(result_dir, ignore_errors=True)

    log_dir = f"{settings['model_path']}/log"
    if os.path.exists(log_dir):
        shutil.rmtree(log_dir, ignore_errors=True)

    os.makedirs(log_dir)

    with open(f"{settings['model_path']}/settings.pkl", "wb") as f:
        pkl.dump(settings, f)
