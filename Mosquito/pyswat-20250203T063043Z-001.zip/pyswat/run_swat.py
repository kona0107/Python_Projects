import asyncio
import os
import re
import subprocess
from typing import Dict
import shutil
import pickle as pkl
from settings import utils, sampling, write, statistic, modifier


def run_swat_model(settings: Dict) -> None:
    """
    Run the SWAT model simulation based on the passed settings dictionary.

    Args:
        settings (dict): A dictionary containing the parsed command-line arguments.

    Returns:
        None
    """
    write.write_input_files(settings)
    if settings["number_of_samples"] == 0:
        settings["latin_hypercube_sampling"] = sampling.get_existing_parameters(settings)
    else:
        settings["latin_hypercube_sampling"] = sampling.get_sampled_parameters(settings)

    settings["number_of_samples"] = settings["latin_hypercube_sampling"][0].shape[0]
    utils.get_default(settings)

    parallel_processes = []
    for i in range(1, settings["parallel"] + 1):
        subprocess_obj = start_parallel_simulation(str(i), settings["model_path"])
        parallel_processes.append(subprocess_obj)

    for subprocess_obj in parallel_processes:
        subprocess_obj.communicate()


def start_parallel_simulation(simulation_id: str, model_path: str) -> subprocess.Popen:
    """
    Run the SWAT model in parallel using the 'run_swat_parallel.py' script.

    Args:
        simulation_id (str): The id of the process.
        model_path (str): The path to the model.

    Returns:
        subprocess.Popen: The subprocess.Popen object.
    """
    subprocess_obj = subprocess.Popen(
        ["python", f"{os.path.abspath(os.path.dirname(__file__))}/run_swat_parallel.py", simulation_id, model_path]
    )
    return subprocess_obj


async def callback(model_path, index, time_step):
    """
    Modify the SWAT model input files and run the simulation.

    Args:
        model_path (str): Path to the SWAT model.
        index (int): Index for the Latin hypercube sampling parameters.
        time_step (int): Time step for the SWAT model simulation.

    Returns:
        None
    """
    with open(f"{model_path}/settings.pkl", "rb") as f:
        settings = pkl.load(f)

    default_parameter_data = utils.load_data(settings["parameter_path"], settings["model_path"])
    copy_dir = f"{settings['model_path']}/TxtInOut_callback"
    shutil.copytree(f"{settings['model_path']}/TxtInOut", copy_dir, dirs_exist_ok=True)
    await modifier.replace_line(
        copy_dir,
        settings["subbasin_number"],
        settings["latin_hypercube_sampling"],
        default_parameter_data,
        index=index,
    )

    os.makedirs(f"{settings['model_path']}/result_callback", exist_ok=True)
    with open(f"{model_path}/TxtInOut_callback/file.cio", "r", encoding="cp949") as f:
        lines = f.readlines()
        for i, line in enumerate(lines):
            if line.find("IPRINT") >= 0:
                lines[i] = re.sub(r"\d+", str(time_step), line)

    with open(f"{settings['model_path']}/TxtInOut_callback/file.cio", "w", encoding="cp949") as f:
        f.writelines(lines)

    os.chdir(copy_dir)
    os.chmod(f"{copy_dir}/{settings['swat_executable']}", 0o775)
    os.system(f"{copy_dir}/{settings['swat_executable']}")
    statistic.calculate_model_performance(
        settings["model_path"],
        settings["observed_data"],
        settings["time_step"],
        settings["calibration_year"],
        settings["validation_year"],
        "callback",
        settings["swat_executable"],
    )
#     statistic.calculate_concentration(
#         settings["model_path"],
#         settings["observed_data"],
#         settings["time_step"],
#         settings["calibration_year"],
#    )

if __name__ == "__main__":
    parser = utils.get_args()
    args = parser.parse_args()
    settings = utils.get_settings(args)

    if settings["callback"] is not None:
        asyncio.run(callback(settings["model_path"], settings["callback"], settings["time_step"]))
    else:
        run_swat_model(settings)
        statistic.combine_statistics(settings["model_path"], settings["parallel"])
        # statistic.calculate_concentration(
        # settings["model_path"],
        # settings["observed_data"],
        # settings["time_step"],
        # settings["calibration_year"],
        # )
        obs = [obs for obs in settings["observed_data"] if ("CORN" not in obs) and ("SOYB" not in obs)]
        statistic.extract_image(
            settings["model_path"], obs, settings["calibration_year"], settings["validation_year"], settings["time_step"]
        )
        write.write_complete_files(settings)
