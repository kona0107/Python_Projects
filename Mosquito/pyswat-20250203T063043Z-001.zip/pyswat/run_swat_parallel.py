import asyncio
import os
import sys
import pickle as pkl
from typing import Dict
from settings import modifier, utils, statistic, log


async def run_simulation(settings: Dict, process_id: int) -> None:
    """Main entry point of the script.

    Args:
        settings: A dictionary containing the parsed command-line arguments.
    """

    default_parameter_data = utils.load_data(settings["parameter_path"], settings["model_path"])
    cnt = settings["number_of_samples"] // settings["parallel"]
    start = cnt * (process_id - 1)
    end = cnt * process_id
    log_file = f"{settings['model_path']}/log/log_{process_id}.log"
    total = end - start

    result_dir = f"{settings['model_path']}/result_{process_id}"
    if os.path.exists(result_dir):
        os.system(f"rm -rf {result_dir}")
    os.makedirs(result_dir, exist_ok=True)

    if os.path.exists(log_file):
        os.remove(log_file)

    copy_dir = f"{settings['model_path']}/TxtInOut_{process_id}"

    if os.path.exists(copy_dir):
        os.system(f"rm -rf {copy_dir}")

    os.system(f"cp -rf {settings['model_path']}/TxtInOut {copy_dir}")

    log.log(log_file, 1, total, "copied TxtInOut directory")

    for i, j in enumerate(range(start, end)):
        log.log(log_file, i + 1, total, "started...")
        os.system(f"cp -rf {settings['model_path']}/TxtInOut/*.sol {copy_dir}")
        os.system(f"cp -rf {settings['model_path']}/TxtInOut/*.mgt {copy_dir}")
        await modifier.replace_line(
            copy_dir, settings["subbasin_number"], settings["latin_hypercube_sampling"], default_parameter_data, index=j
        )
        os.chdir(copy_dir)
        log.log(log_file, i + 1, total, "replaced lines")
        os.chmod(f"{copy_dir}/{settings['swat_executable']}", 0o775)
        os.system(f"{copy_dir}/{settings['swat_executable']}")
        log.log(log_file, i + 1, total, "finished simulation")

        statistic.calculate_model_performance(
            settings["model_path"],
            settings["observed_data"],
            settings["time_step"],
            settings["calibration_year"],
            settings["validation_year"],
            process_id,
            settings["swat_executable"],
        )
        log.log(log_file, i + 1, total, "calculated model performance")

if __name__ == "__main__":
    process_id: int = int(sys.argv[1])
    with open(f"{sys.argv[2]}/settings.pkl", "rb") as f:
        settings = pkl.load(f)

    asyncio.run(run_simulation(settings, process_id))
